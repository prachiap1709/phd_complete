<?php include("include/header.php");?>
<style>th {
    background: #c4c4ff70;
}</style>
            <div class="app-content">
               <div class="side-app">
                
                  <div class="page-header">
                     <ol class="breadcrumb">
                     
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">User Contacted</li>
                     </ol>
                    
                  </div>
              
                  <div class="row">
                    
                     <div class="col-sm-12">
                       <div class="card">
								
									<div class="table-responsive">
										<table class="table card-table table-vcenter text-nowrap">
											<thead>
												<tr>
													<th>ID</th>
													<th>Name</th>
													<th>Email id</th>
													<th>Contact Number</th>
														<th>Contacted Date</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td scope="row">1</td>
													<td><i class="fa fa-user"></i> Gunjan jain</td>
													<td><i class="fa fa-envelope"></i> gunjanjain093@gmail.com</td>
													<td><i class="fa fa-phone"></i> +91-123 456 7894</td>
													<td><i class="fa fa-calendar"></i> 17-05-2022</td>
												</tr>
												<tr>
													<td scope="row">2</td>
													<td><i class="fa fa-user"></i> Gunjan jain</td>
													<td><i class="fa fa-envelope"></i> gunjanjain093@gmail.com</td>
													<td><i class="fa fa-phone"></i> +91-123 456 7894</td>
													<td><i class="fa fa-calendar"></i> 17-05-2022</td>
												</tr>
												
												<tr>
													<td scope="row">3</td>
													<td><i class="fa fa-user"></i> Gunjan jain</td>
													<td><i class="fa fa-envelope"></i> gunjanjain093@gmail.com</td>
													<td><i class="fa fa-phone"></i> +91-123 456 7894</td>
													<td><i class="fa fa-calendar"></i> 17-05-2022</td>
												</tr>
												
												<tr>
													<td scope="row">4</td>
													<td><i class="fa fa-user"></i> Gunjan jain</td>
													<td><i class="fa fa-envelope"></i> gunjanjain093@gmail.com</td>
													<td><i class="fa fa-phone"></i> +91-123 456 7894</td>
													<td><i class="fa fa-calendar"></i> 17-05-2022</td>
												</tr>
											</tbody>
										</table>
									</div>
									<!-- table-responsive -->
								</div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
        <?php include("include/footer.php");?>