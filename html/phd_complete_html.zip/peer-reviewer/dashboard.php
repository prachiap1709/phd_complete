<?php include("include/header.php");?>
            <div class="app-content">
               <div class="side-app">
                
                  <div class="page-header">
                     <ol class="breadcrumb">
                       
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My Dashboard</li>
                     </ol>
                     
                  </div>

				  
				<div class="row mt-4 row-equal-height">
	  <div class="col-sm-4 text-left mb-4">
	  
	  <div class="banner banner-color mt-0 row">
								
								<div class="page-content col-sm-12 pb-0 mt-2 mb-0">
									<h4 class="mb-1 pb-2"><strong>Welcome to Gunjan jain! <a href="editprofile.php" class="btn btn-primary ed-butt mb-1">Edit Profile <i class="fa fa-pencil"></i></a></strong></h4>
									<p class="mb-0 fs-16">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
								
								
<div role="progressbar" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100" style="--value: 67"></div>

								
								</div>
								
							</div>
							
					
								
	  
	  </div>
 
 <div class="col-lg-4">
								<div class="card pb-5">
									<div class="card-header custom-header">
										<div>
											<h3 class="card-title">Public Profile   <a href="#" class="shr">Share Profile <i class="fa fa-share-alt"></i></a></h3>
											
										</div>
									</div>
									<div class="card-body pt-2 pb-2">
										<div class="latest-timeline">
										
											
            <ul class="pr-link">
                <li><i class="fa fa-facebook-f"></i> www.facebook.com</li>
                <li><i class="fa fa-user"></i> 4+ Experience</li>
               <li><i class="fa fa-envelope"></i> gunjanjain093@gmail.com</li>
			   
			   <li class="pt-2"><a href="#">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </a></li>
			   </ul>
										</div>
									</div>
								</div>
							</div>
<div class="col-lg-4">
							<div class="card overflow-hidden">
									<div class="card-header">
										<h5 class="card-title">Latest Contacted</h5>
									</div>
									<div class="card-body p-0">
										<div class="list-group list-group-flush ">
											<div class="list-group-item d-flex  align-items-center">
												<div class="mr-2">
													<img class="mr-3 rounded-circle" width="40" src="images/profile.jpg" alt="avatar">
												</div>
												<div class="">
													<div class=" h6 mb-0 text-dark">Gunjan Jain</div>
													<small class="text-muted">PhD Student
													</small>
												</div>
												<div class="ml-auto">
													<i class="fa fa-calendar">14-05-2022</i>
												</div>
											</div>
											<div class="list-group-item d-flex  align-items-center">
												<div class="mr-2">
													<img class="mr-3 rounded-circle" width="40" src="images/profile.jpg" alt="avatar">
												</div>
												<div class="">
													<div class=" h6 mb-0 text-dark">Gunjan Jain</div>
													<small class="text-muted">PhD Student
													</small>
												</div>
												<div class="ml-auto">
													<i class="fa fa-calendar">14-05-2022</i>
												</div>
											</div>
											<div class="list-group-item d-flex  align-items-center">
												<div class="mr-2">
													<img class="mr-3 rounded-circle" width="40" src="images/profile.jpg" alt="avatar">
												</div>
												<div class="">
													<div class=" h6 mb-0 text-dark">Gunjan Jain</div>
													<small class="text-muted">PhD Student
													</small>
												</div>
												<div class="ml-auto">
													<i class="fa fa-calendar">14-05-2022</i>
												</div>
											</div>
											<div class="list-group-item d-flex  align-items-center">
												<div class="mr-2">
													<img class="mr-3 rounded-circle" width="40" src="images/profile.jpg" alt="avatar">
												</div>
												<div class="">
													<div class=" h6 mb-0 text-dark">Gunjan Jain</div>
													<small class="text-muted">PhD Student
													</small>
												</div>
												<div class="ml-auto">
													<i class="fa fa-calendar">14-05-2022</i>
												</div>
											</div>
											<div class="list-group-item d-flex  align-items-center">
												<div class="mr-2">
													<img class="mr-3 rounded-circle" width="40" src="images/profile.jpg" alt="avatar">
												</div>
												<div class="">
													<div class=" h6 mb-0 text-dark">Gunjan Jain</div>
													<small class="text-muted">PhD Student
													</small>
												</div>
												<div class="ml-auto">
													<i class="fa fa-calendar">14-05-2022</i>
												</div>
											</div>
											<div class="list-group-item d-flex  align-items-center">
												<div class="mr-2">
													<img class="mr-3 rounded-circle" width="40" src="images/profile.jpg" alt="avatar">
												</div>
												<div class="">
													<div class=" h6 mb-0 text-dark">Gunjan Jain</div>
													<small class="text-muted">PhD Student
													</small>
												</div>
												<div class="ml-auto">
													<i class="fa fa-calendar">14-05-2022</i>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>





	  </div>
				  
			
            </div>
            <!-- CONTAINER END -->
         </div>
        <?php include("include/footer.php");?>