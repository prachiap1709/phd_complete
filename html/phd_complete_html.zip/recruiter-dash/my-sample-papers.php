<?php include("include/header.php");?>
            <div class="app-content">
               <div class="side-app">
                  <div class="page-header">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My Sample Papers</li>
                     </ol>
                  </div>

				  
				<div class="row mt-4">
	  <div class="col-sm-12 text-left mb-4"><h4 class="border-bottom pb-3">My Sample Papers</h4></div>
 
 
<div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="images/sample-1.pdf"><img src="images/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
 
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="images/sample-1.pdf"><img src="images/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
 
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="images/sample-1.pdf"><img src="images/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
 
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="images/sample-1.pdf"><img src="images/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
	  </div>
				  
			
            </div>
         </div>
     <?php include("include/footer.php");?>