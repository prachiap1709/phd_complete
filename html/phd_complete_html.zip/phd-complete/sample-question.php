<?php include 'include/header.php';?>
     
      <main>
        
         <section class="slider-area hero-height position-relative fix" style="
               background-size:45%;
               background-repeat: no-repeat;
               background-position:right bottom;
    background-color: #f6f8fb7a;">
            <div class="container pb-5" >
               <div class="row">
			   
			  <div class="col-sm-3">
					<?php include 'include/sidebar.php';?>
			   </div>
			    <div class="col-sm-7"> 
					<h4 class="border-bottom pb-2 mb-3">Sample Question

</h4>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p>
				
				<div class="row">
				<h5 class="pb-2 mb-2 border-bottom">Search Your Sample Question Paper
Lorem </h5>
					
					
					<div class="col-sm-12 pt-3">
						<input type="text" class="form-control" placeholder="Search Question Paper">
						<i class="fa fa-search search-butt"></i>
					</div>
				</div>
				<section class="row mt-4 question">
<div class="col-sm-4">
  <input type="radio" id="control_01" name="select" value="1" checked>
  <label for="control_01">
    <img src="assets/img/pr3.png" class="mt-0">
    <p>Research Paper Name</p>
  </label>
</div>
<div class="col-sm-4">
  <input type="radio" id="control_02" name="select" value="2">
  <label for="control_02">
    <img src="assets/img/pr3.png" class="mt-0">
    <p>Research Paper Name</p>
  </label>
</div>
<div class="col-sm-4">
  <input type="radio" id="control_03" name="select" value="3">
  <label for="control_03">
<img src="assets/img/pr3.png" class="mt-0">
    <p>Research Paper Name</p>
  </label>
</div>
<div class="col-sm-4">
  <input type="radio" id="control_04" name="select" value="3">
  <label for="control_04">
<img src="assets/img/pr3.png" class="mt-0">
    <p>Research Paper Name</p>
  </label>
</div>

<div class="col-sm-4">
  <input type="radio" id="control_05" name="select" value="3">
  <label for="control_05">
<img src="assets/img/pr3.png" class="mt-0">
    <p>Research Paper Name</p>
  </label>
</div>

<div class="col-sm-4">
  <input type="radio" id="control_06" name="select" value="3">
  <label for="control_06">
<img src="assets/img/pr3.png" class="mt-0">
    <p>Research Paper Name</p>
  </label>
</div>
</section>
			
				</div>
				<div class="col-sm-2 pl-0 pr-0">
				
					<div class="side-box mb-3">
					<img src="assets/img/search.png" class="img-fluid w-50 mx-auto mt-3 mb-3">
						<h3>Search Your PhD Learning Requirement on Our Portal</h3>
					</div>
					
					<div class="side-box">
					<img src="assets/img/job2.png" class="img-fluid w-50 mx-auto mt-3 mb-3">
						<h3>Search Your Job on our Portal</h3>
					</div>
				</div>
               </div>
            </div>
         </section>
         <!-- slider-area-end -->
         
         <section>
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-left pt-4">
					<h3 class="border-bottom pb-2 mb-2">Sample Question Paper

</h3>



<div class="row">
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
  <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
 
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
 
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
 
  <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
  <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
 
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
   
   
 <div class="col-sm-3 mb-3">
	<div class="card p-3">
<a href="assets/img/sample-1.pdf"><img src="assets/img/sample1.png" class="img-fluid" style=""></a>
		</div>
 </div>
</div>
					</div>
					
			
			</div>
		 </section>
        
	  
	     <?php include 'include/footer.php';?>