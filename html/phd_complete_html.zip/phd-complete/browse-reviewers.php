<?php include 'include/header.php';?>
     
      <main>
        
         <section class="slider-area hero-height position-relative fix" style="
               background-size:45%;
               background-repeat: no-repeat;
               background-position:right bottom;
    background-color: #f6f8fb7a;">
            <div class="container pb-5" >
               <div class="row">
			   
			   <div class="col-sm-3">
					<?php include 'include/sidebar.php';?>
			   </div>
			    <div class="col-sm-7">
				
						<h4 class="border-bottom pb-3">Browse Reviewers</h4>
						
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
				
				<div class="row">
					<div class="col-sm-7">
						<h5>Lorem Ipsum is simply dummy text of the printing and typesetting</h5>
						
						<ul class="point mt-4">
<li><i class="fa fa-check-circle"></i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's...</li>
<li><i class="fa fa-check-circle"></i>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's...</li>


</ul>
<div class="button-baner">
<a href="#browse-review" class="btn btn-primary">Browser Reviewer <i class="fa fa-angle-double-right ar-right text-light"></i></a>
<a href="register-as-peer-reviewer.php" class="edu-btn mt-5">Become a Reviewer <i class="fa fa-angle-double-right ar-right text-light"></i></a>
					</div></div>
					<div class="col-sm-5"><img src="assets/img/browse.png" class="img-fluid"></div>
				</div>
				
				
				</div>
				<div class="col-sm-2 pl-0 pr-0">
				
					<div class="side-box mb-3">
					<img src="assets/img/search.png" class="img-fluid w-50 mx-auto mt-3 mb-3">
						<h3>Search Your PhD Learning Requirement on Our Portal</h3>
					</div>
					
					<div class="side-box">
					<img src="assets/img/job2.png" class="img-fluid w-50 mx-auto mt-3 mb-3">
						<h3>Search Your Job on our Portal</h3>
					</div>
				</div>
               </div>
            </div>
         </section>
         <!-- slider-area-end -->
         
         
        
	  <section class="pt-45" id="browse-review">
	  <div class="container">
	  <div class="row">
	  <div class="col-sm-12 text-left mb-4"><h4 class="border-bottom pb-3">Our Browse Reviewers
 List</h4></div>
 <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				  
				  
				   <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				  
				   <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				  
				   <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				  
				   <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				  
				   <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				  
				   <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				  
				   <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				     <div class="col-sm-4 grid-item c-2">
                     <div class="eduman-course-main-wrapper mb-30">
                        <div class="eduman-course-wraper">
                       
                           <div class="eduman-course-text">
						   <div class="row">
							<div class="col-sm-4"> <img src="assets/img/user.png" class="user-img two d-flex mb-4 float-left"></div>
							<div class="col-sm-8">  <span class="detail pt-3"> <i class="fa fa-user text-warning mt-1 mr-4"></i>&nbsp;&nbsp;  Gunjan Jain</span>
						    <span class="detail d-flex"> <i class="fa fa-graduation-cap text-warning mt-1 mr-4"></i> &nbsp;&nbsp;B.Com,M.Com</span>
                           </div>
						   
						   <div class="col-sm-12">
							<span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span><span class="tag two">Tag Name</span>
						   </div>
						   </div>
						  
						<p class="">Lorem Ipsum is simply dummy text of the printing and typesetting...</p>
                           </div>
                          
                        </div>
                     </div>
                  </div>
				 
			
	  </div>
	  </div>
	  </section>

        <?php include 'include/footer.php';?>